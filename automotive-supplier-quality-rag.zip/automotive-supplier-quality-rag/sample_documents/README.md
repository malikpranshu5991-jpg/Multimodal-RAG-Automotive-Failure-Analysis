# Sample Documents

This folder contains the public sample document used for the final project demo.

## Main sample document

- `bosch_supplier_quality_requirements.pdf`

This is Bosch's public *Supplier Quality Requirements | Summary & Explanations* document for Mobility Solutions. It is used as the primary demonstration document because it contains:

- long-form automotive supplier-quality requirements text,
- structured tables such as inspection-strategy and capability criteria tables,
- diagrams and visual elements suitable for image-summary retrieval.

## Why this is used in the final project

The assignment requires a domain-specific multimodal PDF with text, tables, and visuals. This Bosch document fits that requirement while also making the project more realistic than a synthetic-only example.

## Notes

- You can still keep the older synthetic sample locally for debugging if needed, but the final repository demo should focus on the Bosch public document.
- Before final screenshots, clear the vector index and ingest only the Bosch sample so retrieval results stay clean and consistent.
