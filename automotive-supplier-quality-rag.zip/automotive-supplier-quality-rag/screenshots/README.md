# Screenshot Checklist

Capture the following screenshots after the server is running successfully and after the Bosch document has been ingested.

## 1. Swagger UI
Open:

```powershell
start http://127.0.0.1:8000/docs
```

Save as: `01_swagger_ui.png`

## 2. Successful ingestion
Run:

```powershell
curl.exe -X POST "http://127.0.0.1:8000/ingest" `
  -F "file=@sample_documents\bosch_supplier_quality_requirements.pdf"
```

Save the terminal output as: `02_ingest_success.png`

## 3. Text query result
Run:

```powershell
$body = @{ question = "What does Bosch expect from suppliers regarding quality management systems?" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `03_query_text.png`

## 4. Table query result
Run:

```powershell
$body = @{ question = "What inspection strategies are assigned to the different groups in Bosch’s overview inspection strategies table?" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `04_query_table.png`

## 5. Image query result
Run:

```powershell
$body = @{ question = "Explain Bosch’s inspection strategies overview diagram." } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `05_query_image.png`

## 6. Health endpoint
Run:

```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method Get
```

Save as: `06_health_endpoint.png`

## Important cleanup step before screenshots

If you tested other PDFs earlier, clear the local index first so only the Bosch document is in the vector store:

```powershell
taskkill /F /IM python.exe
rmdir /S /Q data\chroma_db
rmdir /S /Q data\uploads
```

Then restart the app, ingest the Bosch PDF once, and capture the screenshots.
