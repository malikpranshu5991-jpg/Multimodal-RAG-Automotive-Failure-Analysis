# Bosch Supplier Quality Multimodal RAG for Automotive Supplier Documentation

A FastAPI-based multimodal Retrieval-Augmented Generation (RAG) system for automotive supplier quality teams working with publicly available Bosch supplier quality documentation. The system ingests PDF documents containing narrative text, structured tables, and visual diagrams, then returns grounded answers with page-level source references through a FastAPI API and a lightweight local frontend.

---

## Problem Statement

In automotive supply-chain operations, supplier quality teams rarely make decisions from a single clean dataset. Instead, they work across long supplier quality manuals, audit guidance, process-control requirements, PPAP/PPA deliverables, change-management instructions, and complaint-handling procedures. These documents are often provided as dense PDFs that mix long-form narrative text, tables of requirements, and visual process or inspection diagrams. In practice, supplier quality engineers, procurement stakeholders, manufacturing teams, and launch managers spend significant time manually searching through these documents to answer operational questions such as: what quality management system is expected, what must appear in a control plan, how process capability should be demonstrated, what evidence is needed during PPA/PPAP, or how suppliers must notify Bosch before a change.

This project addresses that problem in the context of publicly available Bosch supplier quality documentation for the Mobility Solutions business sector. The core document used for demonstration is **Supplier Quality Requirements | Summary & Explanations, Edition 3, February 2025**, which contains management-system expectations, assessment and audit requirements, preventive quality guidance, inspection strategies, process capability criteria, control plan expectations, FMEA guidance, Run@Rate requirements, PPA/PPAP evidence requirements, complaint handling, and supplier-initiated change requirements. The problem is therefore not generic PDF question answering. It is a domain-specific retrieval problem where the user needs the right operational answer from the right modality and with the right page reference.

Traditional search performs poorly here. Keywords alone are not enough because similar concepts appear under different terms and the most useful evidence may be split across text, tables, and diagrams. For example, a user may ask about Bosch expectations for supplier quality management systems, the minimum inspection strategies associated with different characteristic classes, the standard values for process capability indices, or the deliverables required during production process and part release. A keyword search may return a nearby heading, but it will often miss the table or diagram that actually clarifies the requirement. Manual reading is too slow for real supplier discussions, escalation reviews, and launch-readiness checks.

What makes this use case unique is its multimodal and engineering-heavy nature. Supplier quality documentation is not just descriptive prose. It contains structured requirement tables, classification schemas, process-flow logic, capability thresholds, and visual summaries that are essential to correct interpretation. Terms such as IATF 16949, VDA 6.3, control plan, PFMEA, SPC, MSA, Run@Rate, PPA/PPAP, SICR, CSL, and requalification are all operationally meaningful within automotive quality systems. A useful assistant must therefore preserve chunk type, capture source metadata, summarize visual content before embedding, and return grounded answers that point back to the source page.

RAG is the right approach for this problem because the user needs answers that remain tied to the exact document version in the repository. Fine-tuning would not be a good fit because supplier-quality manuals can change over time and the evaluator wants answers grounded in the actual uploaded PDF, not a model’s memory. Manual search is too slow, and keyword-only search is too brittle for multimodal documents. A retrieval-augmented pipeline makes it possible to upload a new document, build a searchable index without retraining, and answer questions while returning filename, page number, and chunk type for traceability.

The expected outcome is a practical local assistant for supplier-quality decision support. After ingesting a multimodal PDF, the system should answer questions such as: what Bosch expects regarding supplier quality management systems; what inspection strategies appear in the overview table; what standard values apply for process capability indices; what must be included in a control plan; what evidence is required during PPA/PPAP; and what suppliers must do before implementing product or process changes. The goal is not to replace engineering judgment, but to reduce manual search time, improve consistency in interpreting supplier requirements, and support more efficient discussions between supplier quality, engineering, manufacturing, and procurement teams.

---

## Architecture Overview

### High-level flow

```mermaid
flowchart TD
    A[Upload PDF to /ingest] --> B[PyMuPDF text extraction]
    A --> C[pdfplumber table extraction]
    A --> D[Page render / image extraction]
    D --> E[Vision summary generation]
    B --> F[Chunk builder]
    C --> F
    E --> F
    F --> G[OpenAI embeddings]
    G --> H[ChromaDB persistent vector store]

    I[User question to /query] --> J[Question embedding]
    J --> K[Similarity search in ChromaDB]
    K --> L[Retrieved text / table / image-summary chunks]
    L --> M[Prompt assembly with source references]
    M --> N[Answer generation]
    N --> O[Grounded response + citations]
```

### Design notes

- Text, tables, and image-derived summaries are stored as separate chunk types.
- Visual content is summarized before embedding so that diagrams and page-level visuals are retrievable via text queries.
- ChromaDB stores chunk content together with metadata such as filename, page number, chunk type, and document ID.
- The query response returns both the answer and the source references used for grounding.

---

## Technology Choices

### 1. FastAPI
FastAPI was chosen because the assignment explicitly requires a FastAPI application and evaluates endpoint design, documentation quality, and schema-driven API contracts. It also gives an immediate `/docs` interface for demonstration.

### 2. PyMuPDF + pdfplumber
PyMuPDF is used for efficient PDF access, page rendering, text extraction, and image handling. pdfplumber is used alongside it because it provides a simple path for extracting table-like structures from supplier-quality PDFs.

### 3. OpenAI models
OpenAI is used for embeddings, answer generation, and image-summary generation. This keeps the stack consistent and allows the project to implement the required “summarize image content before embedding” step without introducing extra providers.

### 4. `text-embedding-3-small`
This embedding model provides strong retrieval quality at a practical cost for local assignment-scale use. It is sufficient for chunk-level semantic retrieval across text, tables, and visual summaries.

### 5. ChromaDB
ChromaDB was chosen as a lightweight persistent local vector store with straightforward metadata support. That makes the project easier to run on Windows without requiring additional infrastructure.

### 6. Custom modular pipeline
A small custom RAG pipeline was used instead of a large framework abstraction so that chunking, metadata design, ingestion, and retrieval logic remain transparent and easy to explain in the submission.

---

## Repository Structure

```text
automotive-supplier-quality-rag/
├── README.md
├── requirements.txt
├── .env.example
├── main.py
├── frontend/
│   └── index.html
├── src/
│   ├── api/
│   ├── ingestion/
│   ├── models/
│   ├── retrieval/
│   └── utils/
├── sample_documents/
│   ├── bosch_supplier_quality_requirements.pdf
│   └── README.md
├── screenshots/
│   ├── README.md
│   └── .gitkeep
└── .gitignore
```

---

## Public Sample Document

The repository is demonstrated using a publicly available automotive supplier-quality document:

- `bosch_supplier_quality_requirements.pdf` — Bosch, *Supplier Quality Requirements | Summary & Explanations*, Mobility Solutions, Edition 3, February 2025.

This document is suitable for the assignment because it contains:
- long-form supplier-quality text,
- structured tables such as inspection strategies and capability criteria,
- diagrams and visuals that can be summarized and retrieved.

---

## Setup Instructions

### 1. Clone the repository

```powershell
git clone <your-repository-url>
cd automotive-supplier-quality-rag
```

### 2. Create and activate a virtual environment

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure environment variables

```powershell
Copy-Item .env.example .env
notepad .env
```

Add your OpenAI API key to `.env`:

```env
OPENAI_API_KEY=your_openai_api_key_here
```

### 5. Run the server

```powershell
uvicorn main:app --reload
```

### 6. Open the frontend and Swagger UI

```powershell
start http://127.0.0.1:8000/
start http://127.0.0.1:8000/docs
```

---

## API Documentation

### GET `/health`
Returns service readiness, indexed document count, total chunk count, selected models, and uptime.

Example response:

```json
{
  "status": "ok",
  "model_ready": true,
  "indexed_documents": 1,
  "index_size": 120,
  "uptime_seconds": 42.11,
  "chat_model": "gpt-4.1-mini",
  "vision_model": "gpt-4.1-mini",
  "embedding_model": "text-embedding-3-small"
}
```

### POST `/ingest`
Accepts a PDF file upload, extracts text, tables, and visual content, summarizes the visual content, embeds all chunks, and stores them in ChromaDB.

PowerShell example:

```powershell
curl.exe -X POST "http://127.0.0.1:8000/ingest" `
  -F "file=@sample_documents\bosch_supplier_quality_requirements.pdf"
```

### POST `/query`
Accepts a natural language question, retrieves relevant chunks, and generates a grounded answer with source references.

Example request:

```json
{
  "question": "What does Bosch expect from suppliers regarding quality management systems?",
  "top_k": 6
}
```

### GET `/documents`
Lists indexed documents and chunk counts.

### DELETE `/documents/{document_id}`
Deletes one indexed document by document ID.

---

## Suggested Demo Queries

Use the following queries to demonstrate text, table, visual, and cross-section retrieval on the Bosch document:

1. `What does Bosch expect from suppliers regarding quality management systems?`
2. `What inspection strategies are assigned to the different groups in Bosch’s overview inspection strategies table?`
3. `What are the standard values for process capability indices?`
4. `What must be included in the production control plan according to Bosch?`
5. `What must a supplier do before implementing a product or process change?`
6. `Explain Bosch’s inspection strategies overview diagram.`

---

## Screenshots

The assignment requires six screenshots showing end-to-end execution. Add the captured files to the `screenshots/` folder using the names below and then embed them here before final submission.

Required filenames:

- `01_swagger_ui.png`
- `02_ingest_success.png`
- `03_query_text.png`
- `04_query_table.png`
- `05_query_image.png`
- `06_health_endpoint.png`

Suggested capture commands are documented in `screenshots/README.md`.

Before final submission, replace this placeholder section with embedded images such as:

```markdown
![Swagger UI](screenshots/01_swagger_ui.png)
![Ingest Success](screenshots/02_ingest_success.png)
![Text Query](screenshots/03_query_text.png)
![Table Query](screenshots/04_query_table.png)
![Image Query](screenshots/05_query_image.png)
![Health Endpoint](screenshots/06_health_endpoint.png)
```

---

## Limitations & Future Work

### Current limitations

- The parser uses lightweight heuristics and works best on digitally generated PDFs with reasonably clear structure.
- Complex tables may still require manual inspection if the source PDF exposes table structure poorly.
- Visual retrieval currently uses page-level visual summaries rather than fine-grained region grounding.
- Retrieval is similarity-based and does not yet include reranking or hybrid lexical search.
- The project is designed for local demonstration scale rather than enterprise-scale document volumes.

### Future improvements

- Add hybrid keyword + vector retrieval.
- Add reranking to improve precision for long documents.
- Add document-level filtering so queries can be restricted to the latest uploaded file.
- Add evaluation scripts for retrieval recall and faithfulness.
- Add Docker support and automated tests for easier reproducibility.

---

## How to Capture the Required Screenshots

See `screenshots/README.md` for the exact Windows commands and screenshot mapping.
